<?php
include("../include/header.php");

?>

<h1> Download CSV </h1>
<a href="download.php?csv=download">click to Download CSV</a>
<h1>Download JSON File </h1>
<a href="download.php?json="download">Click to download JSON File</a>

</div>

</div>
</body>
</html>